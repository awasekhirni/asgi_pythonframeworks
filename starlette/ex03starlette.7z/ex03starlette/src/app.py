from starlette.applications import Starlette 
from starlette.responses import PlainTextResponse, JSONResponse 
from starlette.routing import Route,Mount, WebSocketRoute 
from starlette.staticfiles import StaticFiles 
import uvicorn 

def homepage(request):
    return PlainTextResponse('Hello, You are using ASGI-Starlette')


def hijazia(request):
    provincename='Hijaz'
    return PlainTextResponse('Welcome to %s!' % provincename)


def masdar(request):
    return JSONResponse({'uniname':['masdar institute', 'UAE']})


async def websocket_endpoint(websocket):
    await websocket.accept()
    await websocket.send_text('Hello, Welcome to using Websockets!')
    await websocket.close()


def startup():
    print('Ready to go')

routes =[
    Route('/',homepage),
    Route('/hijazia', hijazia),
    Route('/masdar',masdar),
    WebSocketRoute('/ws',websocket_endpoint),
    Mount('/static',StaticFiles(directory='static')),
]

app=Starlette(debug=True, routes=routes, on_startup=[startup])

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)



